#pragma once

#include <string>
#include <map>

using namespace std;


class Abilities {

protected :
	virtual void Attack() = 0;
	virtual void Block() = 0;
};