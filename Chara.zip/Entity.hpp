#pragma once

#include <string>
#include <map>

using namespace std;


class Entity {

};